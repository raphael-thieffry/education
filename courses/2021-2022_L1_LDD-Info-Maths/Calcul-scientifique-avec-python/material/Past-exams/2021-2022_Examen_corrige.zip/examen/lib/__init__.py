from .partieB import corrige
