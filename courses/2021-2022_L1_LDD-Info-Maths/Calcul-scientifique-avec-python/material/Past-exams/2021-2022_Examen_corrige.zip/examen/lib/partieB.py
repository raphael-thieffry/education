import numpy as np


def note(f):
    def out_f(*args, **kwargs):
        try:
            res = f(*args, **kwargs)
        except:
            res = 0
        finally:
            print(f"{f.__name__} ({f.__doc__}): {res}")
        return res
    return out_f


def test(a, x, v):
    tol = 1.e-12
    if abs(a._x-x) < tol and abs(a._v-v) < tol:
        return 1
    else:
        print(a, x, v)
        return 0.5


@note
def test_0(AD):
    """déclaration avec 2 arguments"""
    return test(AD(2, 3), 2, 3)


@note
def test_1(AD):
    """déclaration avec 1 argument"""
    return test(AD(3), 3, 0)


@note
def test_2(AD):
    """Opposé"""
    return test(-AD(2, 3), -2, -3)


@note
def test_3(AD):
    """Addition"""
    a = AD(4, 5)
    b = AD(-3, -2)
    return test(a+b, 1, 3)


@note
def test_4(AD):
    """Soustraction"""
    a = AD(4, 5)
    b = AD(-3, -2)
    return test(a-b, 7, 7)


@note
def test_5(AD):
    """Multiplication"""
    a = AD(4, 5)
    b = AD(-3, -2)
    return test(a*b, -12, -23)


@note
def test_6(AD):
    """Division"""
    a = AD(4, 5)
    b = AD(-3, -2)
    return test(a/b, -4/3, -7/9)


@note
def test_7(AD):
    """puissance"""
    a = AD(3, 2)
    return test(a**2, 9, 12)


@note
def test_8(AD, sin):
    """fonction sin"""
    a = AD(.25*np.pi, 1)
    return test(sin(a), 1/np.sqrt(2), 1/np.sqrt(2))


@note
def test_9(AD, sqrt):
    """fonction sqrt"""
    a = AD(0.5, 1)
    return test(sqrt(a), 1/np.sqrt(2), 1/np.sqrt(2))


@note
def test_10(AD):
    """affichage"""
    a = AD(1, 1)
    if isinstance(a.__str__(), str):
        return 1
    else:
        return 0.5


def corrige(dico):
    print("Calcul de la note : ")
    AD = dico.get('classe', None)
    total = 0
    if AD:
        total += test_0(AD)
        total += test_1(AD)
        total += test_2(AD)
        total += test_3(AD)
        total += test_4(AD)
        total += test_5(AD)
        total += test_6(AD)
        total += test_7(AD)
        total += test_8(AD, dico['sin'])
        total += test_9(AD, dico['sqrt'])
        total += test_10(AD)
    print(f"note obtenue : {total}")
