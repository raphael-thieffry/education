import fnmatch
import os
from IPython.display import display, HTML


def sommaire():
    display(HTML("<hr>"))
    display(HTML("L1 MDD153"))
    display(HTML("<h1>Calcul scientifique avec Python</h1>"))
    display(HTML("<hr>"))
    display(HTML("<h2>Séances de cours</h2>"))
    text = "<ol start='0'>\n"
    for file in sorted(os.listdir('.')):
        if fnmatch.fnmatch(file, 'C*.ipynb'):
            fileName, _ = os.path.splitext(file)
            nb, name = fileName[1:3], fileName[4:]
            text += f"<li> <a href='{file}' target='_blank'>{name}</a>\n"
            stext = "<ol>"
            souiounon = False
            for sfile in sorted(os.listdir('.')):
                if fnmatch.fnmatch(sfile, f'SC{nb}*.ipynb'):
                    sfileName, _ = os.path.splitext(sfile)
                    sname = sfileName[7:]
                    stext += f"<li><a href='{sfile}' target='_blank'>"
                    stext += f"{sname}</a></li>\n"
                    souiounon = True
            stext += "</ol>"
            if souiounon:
                text += stext
            text += "</li>\n"
    text += "</ol>"
    display(HTML(text))
    display(HTML("<hr>"))


def plan_cours(num):
    display(HTML("<hr>"))
    display(HTML("<h2>Plan du cours</h2>"))
    text = "<ol>\n"
    for file in sorted(os.listdir('.')):
        if fnmatch.fnmatch(file, f'SC{num:02d}*.ipynb'):
            fileName, _ = os.path.splitext(file)
            name = fileName[7:]
            text += f"<li> <a href='{file}' target='_blank'>{name}</a></li>\n"
    text += "</ol>"
    display(HTML(text))
    display(HTML("<hr>"))
