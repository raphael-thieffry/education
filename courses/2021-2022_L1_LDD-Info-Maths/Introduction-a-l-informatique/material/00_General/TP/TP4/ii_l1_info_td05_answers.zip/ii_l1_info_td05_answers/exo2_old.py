try:
    fichier = open("jungle2.txt", "r")
    lignes = fichier.readlines()
    c = 0

    for i in range(len(lignes)):
        ligne = lignes[i]

        for j in range(len(ligne)):
            o = ord(ligne[i])
            if o >= 48 and o <= 57:
                c = c + 1
    print(c)

except FileNotFoundError:
    print("Le fichier jungle2.txt n'existe pas")
