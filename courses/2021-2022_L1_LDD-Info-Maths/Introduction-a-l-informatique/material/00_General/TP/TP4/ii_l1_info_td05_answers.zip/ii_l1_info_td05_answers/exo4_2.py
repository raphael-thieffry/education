fichier = open("jungle2.txt", "r")
lignes = fichier.readlines()

mot_max = ''    #mot le plus long
long_max = 0    #longeur du mot le plus long
c = 0           #longueur du mot courant
for i in range(len(lignes)):
    ligne = lignes[i]
    for j in range(len(ligne)):
        car = ligne[j]
        o = ord(car)
        if (o >= 65 and o <= 90) or (o >= 97 and o <= 122):
            #on a trouvé une lettre, on augment la longueur courante
            c = c + 1
        else:
            #on est sur une non-lettre (donc on vient de finir un mot):
            if c > long_max:
                long_max = c
                mot_max = ligne[j-c:j]
            c=0

print(mot_max, long_max)
