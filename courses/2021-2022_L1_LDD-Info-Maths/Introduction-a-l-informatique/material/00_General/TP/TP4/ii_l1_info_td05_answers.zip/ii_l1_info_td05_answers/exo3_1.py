msg = input('Saisir une chaîne de caractères :')
t = [ '' ] * len(msg)

for i in range(len(msg)):
    o = ord(msg[i])
    if o >= 65 and o <= 90:
        #Majuscule
        o13 = (((o - 65) + 13 ) % 26) + 65
    else:
        o13 = o
    print(msg[i], '->', o, '->',  o13)
    t[i] = chr(o13)

print("".join(t))

