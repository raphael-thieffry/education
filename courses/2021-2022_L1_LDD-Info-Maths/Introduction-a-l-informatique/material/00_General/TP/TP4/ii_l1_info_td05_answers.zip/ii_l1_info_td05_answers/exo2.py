fichier = open("cdm.txt", "r")
lignes = fichier.readlines()
for i in range(len(lignes)):
    champs = lignes[i].split(":")
    pays1 = champs[0]
    lignes[i] = pays1 + '\n'

sortie = open("cdm2.txt", "w")
sortie.writelines(lignes)
sortie.close()
