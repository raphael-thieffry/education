from turtle import *



icone = open("star.txt", "r")
lignes = icone.readlines()

h = len(lignes) * 20
l = len(lignes[0]) * 20
speed(0)
up()

for i in range(len(lignes)):
    ligne = lignes[i]
    for j in range(len(ligne)):
        c = ligne[j]
        if c == '#':
            x = j * 20 - l/2
            y = h/2 - i * 20
            goto(x, y)
            down()
            begin_fill()
            goto(x+20, y)
            goto(x+20, y-20)
            goto(x, y-20)
            goto(x, y)
            end_fill()
            up()

done()
