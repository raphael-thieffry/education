from turtle import *

### Exercice 5 amélioré avec des niveaux de gris

icone = open("star.txt", "r")
lignes = icone.readlines()

hauteur = len(lignes) * 20
largeur = len(lignes[0]) * 20
alpha=0.125/2
colormode(1.0)
speed(0)
up()

for i in range(len(lignes)):
    ligne = lignes[i]
    for j in range(len(ligne)):
        c = ligne[j]
        #La couleur de base.
        if c == '#':
            col = 0.0
        else:
            col = 1.0
        num_cases = 0
        #pour chaque case voisine
        for k in range(-1,2):
            for l in range(-1, 2):
                #si la case est bien définie, i.e. si on n'est pas sur un bord
                if (k!= 0 or l!=0) and i+k >= 0 and j+l >=0 and i+k < len(lignes) and j+l <len(ligne):
                    if lignes[i+k][j+l] == '#':
                        col_case = 0
                    else:
                        col_case = 1.0
                    col = col + col_case * alpha
                    num_cases = num_cases + 1
        ### on calcule la moyenne:
        col = col / (1+ alpha*num_cases)
        if col != 0:
            #Petite optimisation, on ne dessine pas les pixels blancs
            x = j * 20 - largeur/2
            y = hauteur/2 - i * 20
            goto(x, y)
            color(col, col,col)
            down()
            begin_fill()
            goto(x+20, y)
            goto(x+20, y-20)
            goto(x, y-20)
            goto(x, y)
            end_fill()
            up()

done()
