input('Choisir un animal parmis Dauphin, Chien, Aigle et Autruche, appuyer sur [entrée] quand vous êtes prêts.')

rep = input('Il a des plumes ?')

if rep == 'oui':
    rep = input('Il vole ?')
    if rep == 'oui':
        print('Aigle')
    else:
        print('Autruche')
else:
    rep = input('Il a des pattes ?')
    if rep == 'oui':
        print('Chien')
    else:
        print('Dauphin')
