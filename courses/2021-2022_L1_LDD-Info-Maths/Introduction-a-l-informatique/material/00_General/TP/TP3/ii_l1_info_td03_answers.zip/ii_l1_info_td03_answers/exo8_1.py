from turtle import *

color("black")
fillcolor("red")
x = 0
y = 200

up()
goto(x, y)
begin_fill()
down()

x = x + 50
y = y - 200
goto(x, y)

x = x - 50
y = y - 200
goto(x, y)

x = x - 50
y = y + 200
goto(x, y)

x = x + 50
y = y + 200
goto(x, y)

end_fill()
up()

done()
