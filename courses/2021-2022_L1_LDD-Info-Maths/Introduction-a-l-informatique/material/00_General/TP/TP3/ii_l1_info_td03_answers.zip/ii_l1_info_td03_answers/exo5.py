entree = input('Saisir une année ? ')
annee = int(entree)

if annee % 4 == 0 and (annee % 400 == 0 or annee % 100 != 0):
    print ('Bissextile')
else:
    print ('Non bissextile')
