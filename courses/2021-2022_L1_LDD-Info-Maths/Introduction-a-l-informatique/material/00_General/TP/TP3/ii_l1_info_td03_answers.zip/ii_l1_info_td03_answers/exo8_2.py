# fichier exo8_2.py
from turtle import *

hauteur = 400
largeur = 400

# Ci dessous le code à compléter.
h2 = hauteur // 2
l2 = largeur // 2

up ()
goto (-largeur - l2, h2)
fillcolor("blue")
down()
begin_fill()
goto (-l2, h2)
goto (-l2, -h2)
goto (-largeur -l2, -h2)
goto (-largeur -l2, h2)
end_fill()
up ()

goto ( - l2, h2)
fillcolor("white")
down()
begin_fill()
goto (l2, h2)
goto (l2, -h2)
goto (-l2, -h2)
goto (-l2, h2)
end_fill()
up ()

goto (l2, h2)
fillcolor("red")
down()
begin_fill()
goto (largeur + l2, h2)
goto (largeur + l2, -h2)
goto (l2, -h2)
goto (l2, h2)
end_fill()
up()

done ()


