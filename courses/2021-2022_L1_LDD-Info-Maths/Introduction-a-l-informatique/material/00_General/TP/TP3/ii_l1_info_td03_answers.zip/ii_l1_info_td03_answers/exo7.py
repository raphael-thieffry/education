#Saisie des coordonnées des deux points
entree = input ('x1 ? ')
x1 = int (entree)
entree = input ('y1 ? ')
y1 = int (entree)
entree = input ('x2 ? ')
x2 = int (entree)
entree = input ('y2 ? ')
y2 = int (entree)

if x1 == x2:
    #droite verticale
    print ('x = ' + str(x1))
else:
    # Sinon, on peut calculer a en soustrayant les deux équations
    # y1 - y2 = ax1 + b - ax2 - b
    # (y1 - y2)/ (x1-x2) = a 
    a = (y1 - y2) / (x1 - x2)
    # On peut ensuite déduire b
    b = y1 - a * x1
    if b < 0:
        print ('y=' + str(a) + '*x' + str(b))
    else:
        print ('y=' + str(a) + '*x+' + str(b))
