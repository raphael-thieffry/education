#!/bin/bash


if test -z "$1"
then
    echo "Il manque un argument au script $0"
elif test ! -e "$1"
then
    echo "Pas de fichier ou répertoire $1"
elif test ! -r "$1"
then
    echo  "$1 n'est pas lisible"
elif test -f "$1"
then
    echo "Nombre de lignes dans le fichier :"
    cat "$1" | wc -l
elif test -d "$1"
then
    echo "Nombre d'entrées dans le répertoire :"
    ls "$1" | wc -l
else
    echo "Type de fichier non supporté"
fi
