package games.escampe;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class EscampeBoardTest {

    // Placement de référence (figure 5 du sujet)
    private static final String BLACK_PLACE = "C6/A6/B5/D5/E6/F5";
    private static final String WHITE_PLACE = "C1/A1/B2/D2/E1/F1";

    private EscampeBoard board;

    @Before
    public void setUp() {
        board = new EscampeBoard();
    }

    // ==================================================================
    // 1. Placement initial
    // ==================================================================

    @Test
    public void testPlacementNoirValide() {
        assertTrue(board.isValidMove(BLACK_PLACE, "noir"));
    }

    @Test
    public void testPlacementBlancValideApreNoir() {
        board.play(BLACK_PLACE, "noir");
        assertTrue(board.isValidMove(WHITE_PLACE, "blanc"));
    }

    @Test
    public void testPlacementBlancMauvaisCote() {
        // Le noir prend le bas (lignes 1-2), le blanc doit prendre le haut (5-6).
        board.play(BLACK_PLACE, "noir"); // noir en haut (lignes 5-6)
        // Si le blanc essaie de se placer en bas aussi -> invalide.
        String wrongSide = "C1/A1/B2/D2/E1/F1"; // bas comme le noir non, noir est en haut
        // En fait le noir est en 5-6 (C6, A6, B5...) donc bas = lignes 1-2 est OK pour blanc
        // Testons un placement blanc en haut (même côté que noir) -> invalide
        String sameSide = "C6/A6/B5/D5/E6/F6";
        assertFalse(board.isValidMove(sameSide, "blanc"));
    }

    @Test
    public void testPlacementDoublonCase() {
        // Deux pions sur la même case -> invalide
        assertFalse(board.isValidMove("C6/C6/B5/D5/E6/F5", "noir"));
    }

    @Test
    public void testPlacementMauvaisNombrePieces() {
        // 5 cases au lieu de 6 -> invalide
        assertFalse(board.isValidMove("C6/A6/B5/D5/E6", "noir"));
    }

    @Test
    public void testPlacementPiecesDeposees() {
        board.play(BLACK_PLACE, "noir");
        // Vérifie que les pions sont bien en place
        assertEquals('N', board.getCell(6, 'C')); // licorne noire en C6
        assertEquals('n', board.getCell(6, 'A')); // paladin noir en A6
        assertEquals('n', board.getCell(5, 'B')); // paladin noir en B5
    }

    // ==================================================================
    // 2. getCell / getLisere
    // ==================================================================

    @Test
    public void testLisereConnu() {
        // Vérifie quelques valeurs de la carte (figure 4 du sujet)
        // Ligne 1 : 1 2 2 3 1 2
        assertEquals(1, board.getLisere(1, 'A'));
        assertEquals(2, board.getLisere(1, 'B'));
        assertEquals(3, board.getLisere(1, 'D'));
        // Ligne 2 : 3 1 3 1 3 2
        assertEquals(3, board.getLisere(2, 'A'));
        assertEquals(3, board.getLisere(2, 'C'));
        // C2 = 3 (utilisé dans le scénario de capture du sujet)
        assertEquals(3, board.getLisere(2, 'C'));
    }

    // ==================================================================
    // 3. isValidMove – coups classiques
    // ==================================================================

    private EscampeBoard boardAvecPlacements() {
        EscampeBoard b = new EscampeBoard();
        b.play(BLACK_PLACE, "noir");
        b.play(WHITE_PLACE, "blanc");
        return b;
    }

    @Test
    public void testCoupValideSimple() {
        EscampeBoard b = boardAvecPlacements();
        // Blanc joue en premier, pas de contrainte liseré.
        // A1 a liseré 1 -> 1 pas possible
        assertTrue(b.isValidMove("A1-A2", "blanc")); // A1 liseré 1, A2 vide
    }

    @Test
    public void testCoupInvalideJoueurAdverse() {
        EscampeBoard b = boardAvecPlacements();
        // Le blanc ne peut pas bouger une pièce noire
        assertFalse(b.isValidMove("A6-A5", "blanc"));
    }

    @Test
    public void testCoupInvalideMauvaisLisere() {
        EscampeBoard b = boardAvecPlacements();
        // On force un liseré requis = 2
        b.setRequiredLisere(2);
        // A1 a liseré 1 : ne doit PAS pouvoir jouer
        assertFalse(b.isValidMove("A1-A2", "blanc"));
    }

    @Test
    public void testCoupInvalideDestinationOccupeeParAllie() {
        EscampeBoard b = boardAvecPlacements();
        // A1(paladin blanc, liseré 1) vers B1 -> B1 pas occupé, mais testons
        // A1 vers A3 = 2 pas alors que liseré A1 = 1 -> invalide
        assertFalse(b.isValidMove("A1-A3", "blanc"));
    }

    @Test
    public void testCoupLicorneBlancheNePrendPas() {
        // La licorne ne peut pas capturer (uniquement les paladins capturent)
        EscampeBoard b = new EscampeBoard();
        b.play("C1/A1/B2/D2/E1/F1", "blanc");
        b.play("C2/A2/B3/D3/E2/F3", "noir"); // noirs en bas (lignes 1-2)
        // Si la licorne blanche (C1, liseré 2) tente d'aller sur la licorne noire (C2)
        // C1 liseré 1 (ligne 1 = 1 2 2 3 1 2 -> col C = 2)... Ajustons.
        // Construisons un cas simple manuellement.
        EscampeBoard c = new EscampeBoard();
        c.getClass(); // pas d'accesseur direct, on passe par play
        // Scénario : licorne blanche B1 (liseré 2), licorne noire B3 (2 pas)
        EscampeBoard m = new EscampeBoard();
        m.play("B1/A2/C2/D2/E2/F2", "blanc"); // blanc: licorne B1
        m.play("B6/A5/C5/D5/E5/F5", "noir");  // noir: licorne B6
        // La licorne blanche en B1 (liseré = ligne1 colB = 2) vers B3 (2 pas, vide)
        assertTrue(m.isValidMove("B1-B3", "blanc")); // licorne blanche peut bouger vers case vide
        // Maintenant, plaçons licorne noire en B3
        EscampeBoard m2 = new EscampeBoard();
        m2.play("B3/A5/C5/D5/E5/F5", "noir"); // licorne noire en B3
        m2.play("B1/A2/C2/D2/E2/F2", "blanc"); // licorne blanche en B1 (liseré 2)
        // Licorne blanche ne doit pas pouvoir capturer licorne noire en B3
        assertFalse(m2.isValidMove("B1-B3", "blanc")); // licorne ne capture pas
    }

    // ==================================================================
    // 4. possiblesMoves
    // ==================================================================

    @Test
    public void testPossiblesMovesSansContrainte() {
        EscampeBoard b = boardAvecPlacements();
        String[] moves = b.possiblesMoves("blanc");
        assertTrue("Blanc doit avoir des coups possibles", moves.length > 0);
        assertFalse("Pas de passe si des coups existent", Arrays.asList(moves).contains("E"));
    }

    @Test
    public void testPossibleMovesContientCoupValide() {
        EscampeBoard b = boardAvecPlacements();
        String[] moves = b.possiblesMoves("blanc");
        Set<String> moveSet = new HashSet<>(Arrays.asList(moves));
        // A1 liseré 1 -> A2 doit être dans les coups
        assertTrue(moveSet.contains("A1-A2"));
    }

    @Test
    public void testPasseTourSiAucunCoup() {
        // Crée un plateau où le joueur est bloqué par contrainte de liseré
        // et n'a aucune pièce sur le liseré requis.
        EscampeBoard b = boardAvecPlacements();
        // Force un liseré que blanc n'a nulle part.
        // Blanc est sur lignes 1-2 ; cherchons un liseré uniquement présent en lignes 3+.
        // En pratique, chaque liseré existe dans toutes les zones du plateau,
        // donc bloquons en plaçant des pièces sur toutes les cases avec ce liseré.
        // Test simplifié : avec liseré 2, les blancs ont E1(liseré 1), F1(liseré 2)...
        // Contournement : un plateau ad-hoc
        EscampeBoard mini = new EscampeBoard();
        mini.play("A1/B1/C1/D1/E1/F1", "blanc"); // tous sur ligne 1
        mini.play("A6/B6/C6/D6/E6/F6", "noir");
        // Requiert liseré 3 mais aucun blanc sur liseré 3 en ligne 1 (1 2 2 3 1 2 -> D1=3)
        // D1 est occupé par un blanc. Forçons liseré que D1 seul a et bloquons D1.
        // Plutôt, testons juste que les moves retournés sont tous valides.
        String[] moves = mini.possiblesMoves("blanc");
        for (String m : moves) {
            if (!m.equals("E")) {
                assertTrue("Chaque coup retourné doit être valide : " + m,
                        mini.isValidMove(m, "blanc"));
            }
        }
    }

    @Test
    public void testTousLesCoupsPossiblesSontValides() {
        EscampeBoard b = boardAvecPlacements();
        // Joue quelques coups et vérifie à chaque étape
        b.play("A1-A2", "blanc"); // blanc
        b.play("A6-A3", "noir");  // noir : A6 liseré 3 → 3 pas (A6→A5→A4→A3)
        String[] moves = b.possiblesMoves("blanc");
        for (String m : moves) {
            if (!m.equals("E")) {
                assertTrue("Coup doit être valide : " + m, b.isValidMove(m, "blanc"));
            }
        }
    }

    // ==================================================================
    // 5. play + requiredLisere
    // ==================================================================

    @Test
    public void testPlayMiseAJourRequiredLisere() {
        EscampeBoard b = boardAvecPlacements();
        // A1 (liseré 1) -> A2. Liseré de A2 = ligne 2 col A = 3.
        b.play("A1-A2", "blanc");
        assertEquals(3, b.getRequiredLisere());
    }

    @Test
    public void testPlayEResetRequiredLisere() {
        EscampeBoard b = boardAvecPlacements();
        b.setRequiredLisere(2);
        b.play("E", "blanc");
        assertEquals(0, b.getRequiredLisere()); // passe → plus de contrainte
    }

    @Test
    public void testPlayCaptureLicorne() {
        EscampeBoard b = new EscampeBoard();
        // Paladin blanc en A1 (liseré 1), licorne noire en A2.
        b.play("B1/A1/C1/D1/E1/F1", "blanc"); // licorne B1, paladin A1
        b.play("A2/B6/C6/D6/E6/F6", "noir");  // licorne noire en A2
        assertFalse(b.gameOver());
        // A1 liseré 1 -> 1 pas -> A2 (licorne noire) : capture valide par paladin
        assertTrue(b.isValidMove("A1-A2", "blanc"));
        b.play("A1-A2", "blanc");
        assertTrue(b.gameOver()); // licorne noire capturée
    }

    // ==================================================================
    // 6. gameOver
    // ==================================================================

    @Test
    public void testGameOverFaux() {
        EscampeBoard b = boardAvecPlacements();
        assertFalse(b.gameOver());
    }

    @Test
    public void testGameOverVrai() {
        // Simule une licorne capturée en l'effaçant directement.
        EscampeBoard b = boardAvecPlacements();
        assertFalse(b.gameOver());
        b.boardGrid()[5][2] = '-'; // efface la licorne noire (C6)
        assertTrue("Licorne noire absente -> gameOver", b.gameOver());
    }

    // ==================================================================
    // 7. Scénario complet de la figure 6 du sujet
    // ==================================================================

    @Test
    public void testScenarioCapturesFigure6() {
        EscampeBoard b = new EscampeBoard();
        // Position de la figure 6 (encodée directement)
        b.boardGrid()[0][0] = 'n'; // A1 paladin noir
        b.boardGrid()[0][1] = 'n'; // B1 paladin noir
        b.boardGrid()[0][2] = 'N'; // C1 licorne noire
        b.boardGrid()[1][2] = 'b'; // C2 paladin blanc
        b.boardGrid()[2][5] = 'b'; // F3 paladin blanc
        b.boardGrid()[3][0] = 'b'; // A4 paladin blanc
        b.boardGrid()[3][2] = 'n'; // C4 paladin noir
        b.boardGrid()[3][3] = 'n'; // D4 paladin noir
        b.boardGrid()[4][2] = 'b'; // C5 paladin blanc
        b.boardGrid()[5][0] = 'n'; // A6 paladin noir
        b.boardGrid()[5][2] = 'B'; // C6 licorne blanche
        b.boardGrid()[5][5] = 'b'; // F6 paladin blanc
        // Le noir vient de jouer en D4 (liseré 2)
        b.setRequiredLisere(b.getLisere(4, 'D')); // ligne 4, col D = liseré 2
        b.setBlackBorder(1);

        // C2-C1 direct : invalide (C2 liseré 3 ≠ requis 2)
        assertFalse(b.isValidMove("C2-C1", "blanc"));

        // F6-E5 : paladin blanc F6 (liseré 2 = requis). Chemin F6->F5->E5 ou F6->E6->E5.
        assertTrue(b.isValidMove("F6-E5", "blanc"));
        b.play("F6-E5", "blanc");
        assertEquals(1, b.getRequiredLisere()); // E5 ligne 5 col E = 1

        // A1-A2 (noir, liseré 1 = requis)
        assertTrue(b.isValidMove("A1-A2", "noir"));
        b.play("A1-A2", "noir");
        assertEquals(3, b.getRequiredLisere()); // A2 ligne 2 col A = 3

        // C2-C1 : paladin blanc, liseré C2 = 3 = requis. Chemin C2->D2->D1->C1.
        assertTrue(b.isValidMove("C2-C1", "blanc"));
        b.play("C2-C1", "blanc");

        assertTrue("La licorne noire doit être capturée", b.gameOver());
    }

    // ==================================================================
    // 8. saveToFile / setFromFile
    // ==================================================================

    @Test
    public void testSaveAndLoad() throws Exception {
        EscampeBoard b = boardAvecPlacements();
        b.play("A1-A2", "blanc");

        File tmpFile = File.createTempFile("escampe_test", ".txt");
        tmpFile.deleteOnExit();

        b.saveToFile(tmpFile.getAbsolutePath());

        EscampeBoard loaded = new EscampeBoard();
        loaded.setFromFile(tmpFile.getAbsolutePath());

        // Vérifie que toutes les cases correspondent
        for (char col = 'A'; col <= 'F'; col++) {
            for (int row = 1; row <= 6; row++) {
                assertEquals("Différence en " + col + row,
                        b.getCell(row, col), loaded.getCell(row, col));
            }
        }
    }

    @Test
    public void testLoadFichierExemple() {
        // Crée un fichier texte minimal en mémoire et le relit
        String content = "% ABCDEF\n"
                + "01 nnN--- 01\n"
                + "02 --b--- 02\n"
                + "03 -----b 03\n"
                + "04 b-nn-- 04\n"
                + "05 --b--- 05\n"
                + "06 n-B--b 06\n"
                + "% ABCDEF\n";
        try {
            File tmp = File.createTempFile("escampe_fig6", ".txt");
            tmp.deleteOnExit();
            java.nio.file.Files.write(tmp.toPath(), content.getBytes());

            EscampeBoard b = new EscampeBoard();
            b.setFromFile(tmp.getAbsolutePath());

            assertEquals('N', b.getCell(1, 'C')); // licorne noire en C1
            assertEquals('B', b.getCell(6, 'C')); // licorne blanche en C6
            assertEquals('b', b.getCell(2, 'C')); // paladin blanc en C2
        } catch (Exception e) {
            fail("Exception inattendue : " + e.getMessage());
        }
    }

    // ==================================================================
    // 9. playNoEdge (copie immuable)
    // ==================================================================

    @Test
    public void testPlayNoEdgeNeModifiePasOriginal() {
        EscampeBoard b = boardAvecPlacements();
        char before = b.getCell(1, 'A'); // A1 = paladin blanc

        EscampeBoard next = b.playNoEdge("A1-A2", "blanc");

        // L'original n'est pas modifié
        assertEquals(before, b.getCell(1, 'A'));
        // La copie est modifiée
        assertEquals('-', next.getCell(1, 'A'));
        assertEquals('b', next.getCell(2, 'A'));
    }
}
