import java.util.HashMap;
class BoolOpException extends IllegalArgumentException{
    BoolExpr exprs[];
    BoolOpException(BoolExpr ...es){exprs=es;}
}

public abstract class BoolExpr{
    abstract boolean eval();
    public static BoolExpr or(BoolExpr...exprs){
        try{return new Or(exprs);}
        catch (BoolOpException e)
        {switch (e.exprs.length){
            case 0: return faux;
            case 1: return e.exprs[0];
            default: return null;
        }
        }
    }
    public static BoolExpr and(BoolExpr...exprs){
        return new And(exprs); }
    public static BoolExpr var(String s){
        return new BoolVar(s); }
    public static BoolCte vrai=new BoolCte(true);
    public static BoolCte faux=new BoolCte(false);
    public static void main(String[] argv){
        BoolExpr e = new And(new BoolCte(true),
                new Or(new BoolCte(false),new BoolCte(true),
                        new BoolCte(false)));
        System.out.println(e.eval());
        BoolExpr e3 = new And(vrai,new Or(faux,vrai,faux));
        System.out.println(e3.eval());
        BoolExpr e2=new And(new BoolVar("truc"),
                new Or(faux, vrai,new BoolVar("bidule")));
        BoolExpr e4 = and(vrai,or(faux,vrai,faux));
        System.out.println(e4.eval());
        BoolExpr e5=and(var("truc"),or(faux, vrai, var("bidule")));
        BoolExpr e6=or();
        BoolExpr e7=or(vrai);
    }

    private abstract static class BoolOp extends BoolExpr{
        BoolExpr[] operands;
        BoolOp(BoolExpr...exprs){
            if(exprs.length<2)
                throw new BoolOpException(exprs);
            operands=exprs;
        }
    }

    private static class And extends BoolOp {
        And(BoolExpr... exprs) { super(exprs); }
        boolean eval() {
            boolean r = true;
            for (BoolExpr e : operands)
                r = r && e.eval();
            return r;
        }
    }
    private static class Or extends BoolOp{
        Or(BoolExpr...exprs){super(exprs);}
        boolean eval(){
            boolean r=false;
            for(BoolExpr e:operands)
                r=r || e.eval();
            return r;
        }
    }

    private static class BoolCte extends BoolExpr{
        boolean cte;
        //on rends le constructeur privé
        private BoolCte(boolean b){cte=b;}
        boolean eval(){return cte;}
        boolean eval2(HashMap<String,Boolean> h){
            return cte;}
    }

    private static class BoolVar extends BoolExpr{
        String id;
        BoolVar(String s){id=s;}
        boolean eval(){return true;}
        boolean eval2(HashMap<String,Boolean> h){
            return h.get(id);}
    } }