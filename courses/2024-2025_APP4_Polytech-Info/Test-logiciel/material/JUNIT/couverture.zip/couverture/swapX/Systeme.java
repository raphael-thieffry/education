package systeme;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

public class Systeme {
   
    private int last = -1;
    private int current = -1;
    private ArrayList<Processus> all = new ArrayList<Processus>();
    static int index = 0;

    public Systeme() {
    }

    public void init() {
	last = -1; current = -1; index = 0;
	all = new ArrayList<Processus>();
    }

    public void add(Processus p) throws ErreurSysteme {
	if (p == null) { throw new ErreurSysteme("Processus null"); }
	if (all.contains(p)) {
	    throw new ErreurSysteme("Processus deja existant");
	}
	all.add(p);
	if (current == -1) { current = 0; }
    }


    public void swap() throws ErreurSysteme {
	int size = all.size();
	if (size < 2) { throw new ErreurSysteme("Nothing waiting"); }
	else if (size == 2) {
	    last = current;
	    current = (current + 1) % 2;
	} else {
	    int avant = current;
	    current = (current+1) % size;
	    if (current == last) { current = (current+1) % size; }
	    last = avant;
	}
    }

    public Collection<Processus> getWaiting() {
	Collection<Processus> res = new HashSet<Processus>();
	for(int i = 0; i < all.size(); i = i+1) {
	    if (i != current) { res.add(all.get(i)); }
	}
	return res;
    }

    public boolean isCurrent(Processus p) {
	return current == -1 ? p == null : all.get(current).equals(p);
    }

    public boolean isLast(Processus p) {
	return last == -1 ? p == null : all.get(last).equals(p);
    }
}

