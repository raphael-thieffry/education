package simpleGame.test;
import simpleGame.core.*;
import simpleGame.exception.OutOfBoardException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.*;

public class TestPawnStub {
	
	Board b;
	Pawn p;
	
	@Before 
	public void Setup(){
		// to be completed:
		// create a mock for Board
		// and stub the necessary methods
		p = new Pawn('p',8,9,b);		
	}
	
	@Test
	public void testGetX(){
		assertEquals(8,p.getX());	
	}
	
	@Test
	public void testGetY(){
		assertEquals(9,p.getY());
	}
	
	@Test
	public void testGetletter(){
		assertEquals('p',p.getLetter());
	}
	
	@Test
	public void testGetGold(){
		assertEquals(0,p.getGold());
	}	
	
	@Test
	public void testIsDead(){
		assertFalse(p.isDead());
	}
	
	// to be completed by other (more interesting) tests
}
