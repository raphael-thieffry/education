package simpleGame.test;
import simpleGame.core.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.*;
import org.mockito.*;

public class TestSequenceDiagram {

	// creation of a mock for Board
	// (alternative to Board b = mock(Board.class);)
	@Mock
	private Board b;
	
	// creation of an instance of Game linked
	// to the mock of Board by injection
	// (the call to the Board constructor inside
	// the Game constructor is replaced by mock b)
	@InjectMocks
	private Game g;
	
	@Test
	public void testIsGameOver() {
		// to be completed
	}
	
	@Test
	public void testMaxGold() {
		// to be completed
	}

	// Mockito technicalities
	private AutoCloseable closeable;
	@Before
	public void openMocks() {
		closeable = MockitoAnnotations.openMocks(this);
	}
	@After
	public void releaseMocks() throws Exception {
		closeable.close();
	}
	
}
