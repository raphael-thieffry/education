	import org.junit.Test;
	import org.junit.Before;
	import static org.junit.Assert.fail;
	import static org.junit.Assert.assertTrue;
	import static org.junit.Assert.assertFalse;
	import static org.junit.Assert.assertEquals;
	import junit.framework.JUnit4TestAdapter;
	
	import java.util.Collection;
	
	public class TestSysteme { 
	
	    Systeme sys;
	    Processus p1, p2, p3, p4, p5;
	
	    @Before public void setUp () throws ErreurSysteme {
		sys = new Systeme();
		p1 = new Processus("p1");
		p2 = new Processus("p2");
		p3 = new Processus("p3");
		p4 = new Processus("p4");
		p5 = new Processus("p5");
		sys.init();
	    }
	
	
	    @Test public void testInit1() { 
		assertTrue(sys.getWaiting().isEmpty());
		assertTrue(sys.isCurrent(null));
		assertTrue(sys.isLast(null));
	    }
	

	    // teste la levee d'exception. En general insuffisant: voir ci-dessous
	    @Test(expected=ErreurSysteme.class)
		public void testInit2() throws ErreurSysteme { sys.swap(); }
	
	    // teste que le swap n'a rien modifie en plus de lever l'exception.
	    // Rale via fail() si l'exception n'a pas été levée.
	    @Test public void testInit2Bis() { 
	    	try { sys.swap(); fail(); }
	    	catch (ErreurSysteme e) { }
		assertTrue(sys.getWaiting().isEmpty());
		assertTrue(sys.isCurrent(null));
		assertTrue(sys.isLast(null));	    	
	    }
	    
	    
	    @Test public void testOne() throws ErreurSysteme {
		sys.add(p1);
		assertTrue(sys.isCurrent(p1));
		assertTrue(sys.getWaiting().isEmpty());
		assertTrue(sys.isLast(null));
	    }
	   
	    @Test
	    public void testOneSwap() throws ErreurSysteme {
		// L'état initial est l'objet d'autres tests.
		// Ici on suppose donc qu'au démarrage d'une méthode
		// de test on est bien dans l'état initial.
		sys.add(p1); // ne doit pas lever l'exception
		try {
		    sys.swap(); // doit lever l'exception
		    fail();     // S'il ne leve rien spontanement on l'aide
		} catch (ErreurSysteme e)  { }
		// vérifie l'état après la levée d'exception
		assertTrue(sys.isLast(null));
		assertTrue(sys.isCurrent(p1));
		assertTrue(sys.getWaiting().isEmpty());
	    }
	    	
	    // autre maniere de faire testOneSwap avec deux méthodes séparées:
	    // une qui vérifie qu'on lève bien l'exception et une autre qui
	    // vérifie l'état du système apres cette levée d'exception
	    @Test(expected=ErreurSysteme.class)
	    public void testOnec() throws ErreurSysteme {
		sys.add(p1);
		sys.swap();
	    }
	    
	    @Test
	    public void testOnecBis() throws ErreurSysteme {
		sys.add(p1);
		try { sys.swap();
		    // pas de fail() ici, puisque testOnec a pour but de
		    // de vérifier que cette levée d'exception a bien lieu.
		} catch (ErreurSysteme e)  { }
		assertTrue(sys.isLast(null));
		assertTrue(sys.isCurrent(p1));
		assertTrue(sys.getWaiting().isEmpty());
	    }
	    
	    public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(TestSysteme.class);
	    }

	}
