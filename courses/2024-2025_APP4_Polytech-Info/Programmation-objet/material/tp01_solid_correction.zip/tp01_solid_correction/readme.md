# SOLID

## Requirements

- [libcurl](https://curl.se/libcurl/)
- [CMake](https://cmake.org/) (3.8+)

## Build instructions (Linux)

First build:

```sh
mkdir build
cd build
cmake ../
make
```

Then simply `make` to rebuild.

## Consignes

Chaque dossier contient un fragment de code qui effectue une tache donnée (spécifiée dans le fichier).
Ces codes ont un design qui met en défaut une des règle SOLID. Chaque dossier est nommé par la règle
SOLID qui est malmenée.

Votre travail consiste à:
  - compiler le code existant et s'assurer de son fonctionnement correct. La sortie que vous obtiendrez fera office de référence.
  - modifier le code de chaque dossier de façon à améliorer le respect de la règle SOLID correspondante.
  - vérifier que votre code donne bien les mêmes résultats mais avec un design de meilleur qualité.
  - rédiger un commentaire expliquant comment et pourquoi votre nouveau design respecte SOLID d'une manière adéquate.

Vous utiliserez le CMake fournir pour compiler les codes avec les bonnes dépendances.
