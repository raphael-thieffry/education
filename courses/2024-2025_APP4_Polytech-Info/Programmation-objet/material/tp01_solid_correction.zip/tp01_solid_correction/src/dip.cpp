#include <algorithm>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <unordered_map>

#include <downloader.hpp>

char encode_char(char c) { return c + 23; }
char decode_char(char c) { return c - 23; }

class database_t {
  inline static std::unordered_map<int, std::string> _data;
  inline static int _count = 0;

public:
  int write(std::string input_string) {
    _data[_count] = input_string;
    return _count++;
  }
};

class encoding_module_t {
public:
  void encode_with_files() {
    std::ifstream ifile("before_encryption.txt");
    std::ofstream ofile("after_encryption.txt");
    std::transform(std::istreambuf_iterator<char>(ifile),
                   std::istreambuf_iterator<char>(),
                   std::ostreambuf_iterator<char>(ofile), &encode_char);
  }

  void encode_based_on_network_and_database() {
    auto txt = download("https://google.fr/");
    if (!txt)
      return;
    std::transform(txt->begin(), txt->end(), txt->begin(), &encode_char);
    database_t database;
    database.write(*txt);
  }
};

int main() {
  if (auto data = download("https://www.lri.fr/"); data)
    std::cout << *data;
  else
    std::cout << ":(\n";

  encoding_module_t encoding_module;
  encoding_module.encode_with_files();
  encoding_module.encode_based_on_network_and_database();
}
