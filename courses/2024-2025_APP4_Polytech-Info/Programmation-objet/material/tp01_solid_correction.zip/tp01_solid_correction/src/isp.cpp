#include <chrono>
#include <random>
#include <stdexcept>
#include <thread>

inline static int val_get_next_random_bool = 0;
bool get_next_random_bool() { return ++val_get_next_random_bool % 3; }

struct door_i {
  virtual void lock() = 0;
  virtual void unlock() = 0;
  virtual void open() = 0;
  virtual void close() = 0;
  virtual void timeout_callback() = 0;
  virtual void proximity_callback() = 0;
  virtual ~door_i() = default;
};

class sensor_t {
public:
  void register_sensor(door_i &door) {
    while (true) {
      if (is_person_close()) {
        door.proximity_callback();
        break;
      }
    }
  }

private:
  bool is_person_close() { return get_next_random_bool(); }
};

class sensing_door_t : public door_i {
private:
  bool _locked;

private:
  bool _opened;

public:
  sensing_door_t(sensor_t sensor) { sensor.register_sensor(*this); }

  void lock() override { _locked = true; }
  void unlock() override { _locked = false; }
  void open() override {
    if (!_locked) {
      _opened = true;
    }
  }
  void close() override { _opened = false; }
  void timeout_callback() override {
    throw std::runtime_error("Not implemented.");
  }
  void proximity_callback() override { _opened = true; }
};

class custom_timer_t {
public:
  void register_sensor(long timeout, door_i *door_ptr) {
    std::thread([=]() {
      std::this_thread::sleep_for(std::chrono::milliseconds(timeout));
      door_ptr->timeout_callback();
    });
  }
};

class timed_door_t : public door_i {
  inline static constexpr int _timeout = 100;
  bool _locked;
  bool _opened;

public:
  timed_door_t(custom_timer_t timer) { timer.register_sensor(_timeout, this); }

  void lock() override { _locked = true; }
  void unlock() override { _locked = false; }
  void open() override {
    if (!_locked) {
      _opened = true;
    }
  }
  void close() override { _opened = false; }
  void timeout_callback() override { _locked = true; }
  void proximity_callback() override {
    throw std::runtime_error("Not implemented.");
  }
};

int main() {}
