#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

class car_t {
private:
  std::string _id;
  std::string _model;
  std::string _brand;

public:
  car_t(std::string id, std::string model, std::string brand)
      : _id(std::move(id)), _model(std::move(model)), _brand(std::move(brand)) {
  }

public:
  std::string const &get_id() const noexcept { return _id; }
  std::string const &get_model() const noexcept { return _model; }
  std::string const &get_brand() const noexcept { return _brand; }
};

class car_manager_t {
private:
  std::vector<car_t> _carsDb = {car_t("1", "Golf III", "Volkswagen"),
                                car_t("2", "Multipla", "Fiat"),
                                car_t("3", "Megane", "Renault")};

public:
  std::optional<car_t> get_car_by_id(std::string const &carId) {
    for (car_t car : _carsDb)
      if (car.get_id() == carId)
        return car;
    return std::nullopt;
  }

  std::string get_cars_names() {
    std::ostringstream sb;
    for (car_t car : _carsDb)
      sb << car.get_brand() << " " << car.get_model() << ", ";
    return sb.str();
  }

  std::optional<car_t> get_best_car() {
    std::optional<car_t> best_car;
    for (car_t car : _carsDb)
      if (!best_car || car.get_model() > best_car->get_model())
        best_car = car;
    return best_car;
  }
};

int main() {
  car_manager_t manager;
  std::cout << manager.get_cars_names() << '\n';
  std::cout << manager.get_best_car()->get_model() << '\n';

  auto my_car = manager.get_car_by_id("2");
  auto no_car = manager.get_car_by_id("4");

  std::cout << (my_car ? my_car->get_model() : "No such car") << '\n';
  std::cout << (no_car ? no_car->get_model() : "No such car") << '\n';
}
