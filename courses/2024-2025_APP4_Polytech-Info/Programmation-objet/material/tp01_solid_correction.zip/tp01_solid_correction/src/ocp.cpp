#include <array>
#include <iostream>
#include <list>

enum resource_type_t { TIME_SLOT, SPACE_SLOT };

class resource_allocator_t {
public:
  inline static const int INVALID_RESOURCE_ID = -1;
  inline static const int MAX_RESOURCE_ID = 10;

  resource_allocator_t() {
    // Nobody is busy
    for (auto &s : spaceSlots)
      s = false;
    for (auto &s : timeSlots)
      s = false;
  }

  int allocate(resource_type_t resourceType) {
    int resource_id;
    switch (resourceType) {
    case TIME_SLOT:
      resource_id = findFreeTimeSlot();
      if (resource_id != INVALID_RESOURCE_ID)
        markTimeSlotBusy(resource_id);
      break;
    case SPACE_SLOT:
      resource_id = findFreeSpaceSlot();
      if (resource_id != INVALID_RESOURCE_ID)
        markSpaceSlotBusy(resource_id);
      break;
    default:
      std::cout << "ERROR: Attempted to allocate invalid resource";
      resource_id = INVALID_RESOURCE_ID;
      break;
    }
    return resource_id;
  }

public:
  void free(resource_type_t resourceType, int resource_id) {
    switch (resourceType) {
    case TIME_SLOT:
      if (resource_id != INVALID_RESOURCE_ID)
        markTimeSlotFree(resource_id);
      break;
    case SPACE_SLOT:
      if (resource_id != INVALID_RESOURCE_ID)
        markSpaceSlotFree(resource_id);
      break;
    default:
      std::cout << "ERROR: attempted to free invalid resource";
      break;
    }
  }

private:
  std::array<bool, MAX_RESOURCE_ID> spaceSlots;
  std::array<bool, MAX_RESOURCE_ID> timeSlots;

private:
  void markSpaceSlotFree(int resource_id) {
    std::cout << resource_id << ": space slot is free\n";
    spaceSlots[resource_id] = false;
  }

  void markTimeSlotFree(int resource_id) {
    std::cout << resource_id << ": time slot is free\n";
    timeSlots[resource_id] = false;
  }

  void markSpaceSlotBusy(int resource_id) {
    std::cout << resource_id << ": space slot is busy\n";
    spaceSlots[resource_id] = true;
  }

  int findFreeSpaceSlot() {
    for (std::size_t i = 0; i < MAX_RESOURCE_ID; ++i)
      if (!spaceSlots[i])
        return i;
    return INVALID_RESOURCE_ID;
  }

  void markTimeSlotBusy(int resource_id) {
    std::cout << resource_id << ": time slot is busy\n";
    timeSlots[resource_id] = true;
  }

  int findFreeTimeSlot() {
    for (std::size_t i = 0; i < MAX_RESOURCE_ID; ++i)
      if (!timeSlots[i])
        return i;
    return INVALID_RESOURCE_ID;
  }
};

int main() {
  resource_allocator_t manager;
  std::list<int> time_allocations;
  std::list<int> space_allocations;

  for (int i = 0; i <= 15; ++i) {
    auto r = manager.allocate(TIME_SLOT);
    if (r != resource_allocator_t::INVALID_RESOURCE_ID) {
      time_allocations.push_back(r);
    } else {
      auto r = time_allocations.front();
      time_allocations.pop_front();
      manager.free(TIME_SLOT, r);
    }
  }

  for (int i = 0; i <= 15; ++i) {
    auto r = manager.allocate(SPACE_SLOT);
    if (r != resource_allocator_t::INVALID_RESOURCE_ID) {
      space_allocations.push_back(r);
    } else {
      auto r = space_allocations.front();
      space_allocations.pop_front();
      manager.free(SPACE_SLOT, r);
    }
  }
}
