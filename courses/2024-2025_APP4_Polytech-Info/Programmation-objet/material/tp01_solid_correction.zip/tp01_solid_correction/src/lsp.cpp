#include <iostream>
#include <memory>
#include <vector>

class duck_t {
public:
  virtual void quack() { std::cout << "Quack..."; }

public:
  virtual void swim() { std::cout << "Swim..."; }
};

class electronic_duck_t : public duck_t {
private:
  bool _on = false;

public:
  void quack() override {
    if (_on)
      std::cout << "Electronic duck quack...";
    else
      throw std::runtime_error("Can't quack when off");
  }

  void swim() override {
    if (_on)
      std::cout << "Electronic duck swim...";
    else
      throw std::runtime_error("Can't swim when off");
  }

  void turn_on() { _on = true; }
  void turn_off() { _on = false; }
};

class pool_t {
public:
  void run() {
    duck_t donald_duck;
    electronic_duck_t electronic_duck;
    quack({&donald_duck, &electronic_duck});
    swim({&donald_duck, &electronic_duck});
  }

private:
  void quack(std::vector<duck_t *> const &ducks) {
    for (duck_t *duck_ptr : ducks)
      duck_ptr->quack();
  }

  void swim(std::vector<duck_t *> const &ducks) {
    for (duck_t *duck_ptr : ducks)
      duck_ptr->swim();
  }
};

int main() {
  pool_t pool;
  pool.run();
}
