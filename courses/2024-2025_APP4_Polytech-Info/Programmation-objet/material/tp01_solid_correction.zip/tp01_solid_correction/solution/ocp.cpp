#include <array>
#include <iostream>
#include <list>

// OCP - Open/Close Principle

// On souhaite avoir un allocator qui puisse etre extensible, sans avoir a le
// modifier. Pour ca on identifie le code qui se repete dans les switches,
// et on voit ce qu'on peut rendre polymorphe; a savoir:

// - find_free
// - mark_busy
// - mark_free

// Par facilite on choisit de les implementer directement dans les ressources.

inline static const int MAX_RESOURCE_ID = 10;
inline static const int INVALID_RESOURCE_ID = -1;

struct resource_i {
  virtual int find_free() = 0;
  virtual void mark_busy(int resource_id) = 0;
  virtual void mark_free(int resource_id) = 0;
  virtual ~resource_i() = default;
};

class resource_allocator_t {
public:
  int allocate(resource_i &resource) {
    int resource_id = resource.find_free();
    if (resource_id != INVALID_RESOURCE_ID)
      resource.mark_busy(resource_id);
    return resource_id;
  }

  void free(resource_i &resource, int resource_id) {
    if (resource_id != INVALID_RESOURCE_ID)
      resource.mark_free(resource_id);
  }
};

class space_resource_t : public resource_i {
public:
  int find_free() override {
    for (std::size_t i = 0; i < MAX_RESOURCE_ID; ++i)
      if (!slots[i])
        return i;
    return INVALID_RESOURCE_ID;
  }
  void mark_busy(int resource_id) override {
    std::cout << resource_id << ": space slot is busy\n";
    slots[resource_id] = true;
  }
  void mark_free(int resource_id) override {
    std::cout << resource_id << ": space slot is free\n";
    slots[resource_id] = false;
  }

private:
  static std::array<bool, MAX_RESOURCE_ID> slots;
};

std::array<bool, MAX_RESOURCE_ID> space_resource_t::slots = {};

class time_resource_t : public resource_i {
public:
  int find_free() override {
    for (std::size_t i = 0; i < MAX_RESOURCE_ID; ++i)
      if (!slots[i])
        return i;
    return INVALID_RESOURCE_ID;
  }

  void mark_busy(int resource_id) override {
    std::cout << resource_id << ": time slot is busy\n";
    slots[resource_id] = true;
  }
  void mark_free(int resource_id) override {
    std::cout << resource_id << ": time slot is free\n";
    slots[resource_id] = false;
  }

private:
  static std::array<bool, MAX_RESOURCE_ID> slots;
};

std::array<bool, MAX_RESOURCE_ID> time_resource_t::slots = {};

int main() {
  resource_allocator_t manager;
  std::list<int> time_allocations;
  std::list<int> space_allocations;

  for (int i = 0; i <= 15; ++i) {
    time_resource_t t;
    auto r = manager.allocate(t);
    if (r != INVALID_RESOURCE_ID) {
      time_allocations.push_back(r);
    } else {
      auto r = time_allocations.front();
      time_allocations.pop_front();
      manager.free(t, r);
    }
  }

  for (int i = 0; i <= 15; ++i) {
    space_resource_t s;
    auto r = manager.allocate(s);
    if (r != INVALID_RESOURCE_ID) {
      space_allocations.push_back(r);
    } else {
      auto r = space_allocations.front();
      space_allocations.pop_front();
      manager.free(s, r);
    }
  }
}
