#include <chrono>
#include <random>
#include <thread>

// ISP - Interface Segregation Principle

// door_t presente un probleme: elle est trop lourde. Une porte n'a pas
// necessairement de capteur de proximite ni de timer. Il convient donc
// de separer ces interfaces de celle de la porte dans des interfaces
// dediees, plutot que de les implementer pour toutes les portes en
// mettant une exception pour faire joli.

inline static int val_get_next_random_bool = 0;
bool get_next_random_bool() { return ++val_get_next_random_bool % 3; }

struct door_i {
  virtual void lock() = 0;
  virtual void unlock() = 0;
  virtual void open() = 0;
  virtual void close() = 0;
  virtual ~door_i() = default;
};

struct sensor_client_i {
  virtual void proximity_callback() = 0;
  virtual ~sensor_client_i() = default;
};

struct timer_client_i {
  virtual void timeout_callback() = 0;
  virtual ~timer_client_i() = default;
};

class sensor_t {
public:
  void register_client(sensor_client_i &sensor_client) {
    while (true) {
      if (is_person_close()) {
        sensor_client.proximity_callback();
        break;
      }
    }
  }

private:
  bool is_person_close() { return get_next_random_bool(); }
};

class sensing_door_t : public door_i, sensor_client_i {
  bool _locked;
  bool _opened;

public:
  sensing_door_t(sensor_t sensor) { sensor.register_client(*this); }

  void lock() override { _locked = true; }
  void unlock() override { _locked = false; }
  void open() override {
    if (!_locked) {
      _opened = true;
    }
  }

  void close() override { _opened = false; }
  void proximity_callback() override { _opened = true; }
};

class custom_timer_t {
public:
  void register_client(long timeout, timer_client_i *timer_client_ptr) {
    std::thread([=]() {
      std::this_thread::sleep_for(std::chrono::milliseconds(timeout));
      timer_client_ptr->timeout_callback();
    });
  }
};

class timed_door_t : public door_i, timer_client_i {
  inline static constexpr int _timeout = 100;
  bool _locked;
  bool _opened;

public:
  timed_door_t(custom_timer_t timer) { timer.register_client(_timeout, this); }

  void lock() override { _locked = true; }
  void unlock() override { _locked = false; }
  void open() override {
    if (!_locked) {
      _opened = true;
    }
  }
  void close() override { _opened = false; }
  void timeout_callback() override { _locked = true; }
};

int main() {}
