#include <algorithm>
#include <fstream>
#include <memory>
#include <string>
#include <unordered_map>

#include <downloader.hpp>

// DIP - Dependency Inversion Principle

// Dans ce code, encoding_module_t depend de l'implementation de la
// lecture/ecriture, ce qui va a l'encontre du DIP qui voudrait qu'on depende
// d'une abstraction et non pas d'une implementation.

// Pour ca on cree les interfaces reader_i_t et writer_i_t, puis on rajoute
// des implementations qui y repondent, et on fait en sorte que l'encodeur
// soit compatible avec ces interfaces. Le code devient plus simple et plus
// modulaire, on peut combiner plus facilement les readers/writers sans
// toucher a la classe encoder.

char encode_char(char c) { return c + 23; }
char decode_char(char c) { return c - 23; }

struct reader_i_t {
  virtual std::string read() = 0;
  virtual ~reader_i_t() = default;
};

struct writer_i_t {
  virtual void write(std::string output) = 0;
  virtual ~writer_i_t() = default;
};

class encoding_module_t {
public:
  void encode(reader_i_t &reader, writer_i_t &writer) {
    auto txt = reader.read();
    std::transform(txt.begin(), txt.end(), txt.begin(), &encode_char);
    writer.write(txt);
  }
};

class database_t {
  inline static std::unordered_map<int, std::string> _data;
  inline static int _count = 0;

public:
  int write(std::string input_string) {
    _data[_count] = input_string;
    return _count++;
  }
};

class database_writer_t : public writer_i_t {
public:
  void write(std::string input) override {
    database_t database;
    database.write(input);
  }
};

class file_reader_t : public reader_i_t {
private:
  std::string _path;

public:
  file_reader_t(std::string path) : _path(std::move(path)) {}

  std::string read() override {
    std::ifstream in(_path);
    return {std::istreambuf_iterator<char>(in),
            std::istreambuf_iterator<char>()};
  }
};

class file_writer_t : public writer_i_t {
private:
  std::string _path;

public:
  file_writer_t(std::string path) : _path(path) {}

  void write(std::string output) override {
    std::ofstream out(_path);
    std::copy(output.begin(), output.end(),
              std::ostreambuf_iterator<char>(out));
  }
};

class network_reader_t : public reader_i_t {
  std::string _url;

public:
  network_reader_t(std::string url) : _url(std::move(url)) {}

  std::string read() override {
    auto res = download(_url);
    return res ? *res : "";
  }
};

int main() {
  encoding_module_t encoding_module;

  std::unique_ptr<reader_i_t> reader =
      std::make_unique<file_reader_t>("before_encryption.txt");
  std::unique_ptr<writer_i_t> writer =
      std::make_unique<file_writer_t>("after_encryption.txt");
  encoding_module.encode(*reader, *writer);

  reader = std::make_unique<network_reader_t>("https://www.lri.fr/");
  writer = std::make_unique<database_writer_t>();
  encoding_module.encode(*reader, *writer);
}
