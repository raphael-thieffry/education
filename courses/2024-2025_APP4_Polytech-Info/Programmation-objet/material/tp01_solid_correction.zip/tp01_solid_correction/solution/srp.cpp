#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

// SRP - Single Responsibility Principle

// Correction: On passe d'une classe car_manager_t monolithique a une classe
// car_manager_t plus simple qui repose sur des sous-classes pour deleguer
// le formatage, la comparaison des modeles, et la gestion de la BDD.

class car_t {
  std::string _id;
  std::string _model;
  std::string _brand;

public:
  car_t(std::string id, std::string model, std::string brand)
      : _id(std::move(id)), _model(std::move(model)), _brand(std::move(brand)) {
  }

  std::string const &get_id() const noexcept { return _id; }
  std::string const &get_model() const noexcept { return _model; }
  std::string const &get_brand() const noexcept { return _brand; }
};

class car_dao_t {
  std::vector<car_t> _carsDb = {car_t("1", "Golf III", "Volkswagen"),
                                car_t("2", "Multipla", "Fiat"),
                                car_t("3", "Megane", "Renault")};

public:
  std::optional<car_t> find_by_id(std::string const &carId) noexcept {
    for (car_t &car : _carsDb)
      if (car.get_id() == carId)
        return car;
    return std::nullopt;
  }

  std::vector<car_t> const &find_all() const { return _carsDb; }
};

class car_formatter_t {
public:
  std::string get_cars_names(std::vector<car_t> const &cars) {
    std::ostringstream sb;
    for (car_t car : cars)
      sb << car.get_brand() << " " << car.get_model() << ", ";
    return sb.str();
  }
};

class car_rater_t {
public:
  std::optional<car_t> get_best_car(std::vector<car_t> const &cars) {
    std::optional<car_t> bestcar_t;
    for (car_t car : cars)
      if (!bestcar_t || car.get_model() > bestcar_t->get_model())
        bestcar_t = car;
    return bestcar_t;
  }
};

class car_manager_t {
  car_dao_t _car_dao;
  car_formatter_t _car_formatter;
  car_rater_t _car_rater;

public:
  car_manager_t(car_dao_t carDao, car_formatter_t carFormatter,
                car_rater_t carRater)
      : _car_dao(std::move(carDao)), _car_formatter(std::move(carFormatter)),
        _car_rater(std::move(carRater)) {}

  std::optional<car_t> get_car_by_id(std::string const &carId) {
    return _car_dao.find_by_id(carId);
  }

  std::string get_cars_names() {
    return _car_formatter.get_cars_names(_car_dao.find_all());
  }

  std::optional<car_t> get_best_car() {
    return _car_rater.get_best_car(_car_dao.find_all());
  }
};

int main() {
  car_manager_t manager({}, {}, {});
  std::cout << manager.get_cars_names() << '\n';
  std::cout << manager.get_best_car()->get_model() << '\n';

  auto my_car = manager.get_car_by_id("2");
  auto no_car = manager.get_car_by_id("4");

  std::cout << (my_car ? my_car->get_model() : "No such car") << '\n';
  std::cout << (no_car ? no_car->get_model() : "No such car") << '\n';
}
