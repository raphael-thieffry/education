cmake_minimum_required(VERSION 3.8)

project(SOLID LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
include_directories("include")

find_package(CURL REQUIRED)
# sudo apt update && sudo apt install curl && sudo apt-get install libcurl4-openssl-dev

add_executable(dip src/dip.cpp)
target_include_directories(dip PUBLIC ${CURL_INCLUDE_DIRS})
target_link_libraries(dip PUBLIC ${CURL_LIBRARIES})

add_executable(isp src/isp.cpp)
add_executable(lsp src/lsp.cpp)
add_executable(ocp src/ocp.cpp)
add_executable(srp src/srp.cpp)

if(CORRECTION)
  add_executable(dip_correction solution/dip.cpp)
  target_include_directories(dip_correction PUBLIC ${CURL_INCLUDE_DIRS})
  target_link_libraries(dip_correction PUBLIC ${CURL_LIBRARIES})

  add_executable(isp_correction solution/isp.cpp)
  add_executable(lsp_correction solution/lsp.cpp)
  add_executable(ocp_correction solution/ocp.cpp)
  add_executable(srp_correction solution/srp.cpp)
endif(CORRECTION)
