#pragma once

#include <optional>
#include <string>
#include <string_view>

#include <curl/curl.h>

namespace detail_download {
inline static bool is_curl_init = false;

size_t dl_cb(void *contents, size_t size, size_t nmemb, std::string *txt_ptr) {
  auto const sz = size * nmemb;
  txt_ptr->append((char *)(contents), sz);
  return sz;
}
} // namespace detail_download

std::optional<std::string> download(std::string_view url) {
  std::string txt;

  // libcurl init check
  if (!detail_download::is_curl_init) {
    curl_global_init(CURL_GLOBAL_ALL);
    std::atexit(&curl_global_cleanup);
  }

  auto handle = curl_easy_init();
  if (!handle)
    return std::nullopt;

  curl_easy_setopt(handle, CURLOPT_URL, url.data());
  curl_easy_setopt(handle, CURLOPT_WRITEDATA, &txt);
  curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, &detail_download::dl_cb);
  curl_easy_setopt(handle, CURLOPT_USERAGENT, "Sous la cagoule c'est JuL/1.0");

  auto res = curl_easy_perform(handle);
  curl_easy_cleanup(handle);
  if (res != CURLE_OK)
    return std::nullopt;
  return txt;
}
