# TP1-Ex1
	
	.data

	.text
	.globl main
main:
	li $t0,0x12345678
	li $t1, 0x00000001
	and $t2, $t0, $t1
	or $t3, $t0, $t1
	addu $t4,$t2, $t3
	jr $ra



