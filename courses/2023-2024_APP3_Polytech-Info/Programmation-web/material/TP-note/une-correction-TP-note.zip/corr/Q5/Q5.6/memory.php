<?php
  $nom=$_GET['nom'];
  $taille=$_GET['taille'];
  if($taille > 5 || $taille < 2) {
    echo '<h1>Valeur interdite !</h1>';
    exit();
    }
?>

<!DOCTYPE html>
<html lang="fr">
  <head>
    <title>Memory (TP noté APP3)</title>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="./css/style.css" rel="stylesheet" type="text/css" media="screen">
      <script type="text/javascript" src="./js/memory.js"></script>
      <script type="text/javascript" src="./js/delay.min.js"></script>
  </head>
  <body>


    <div id="main">

    <?php
    echo '<h1>'.$nom.'</h1>';
    ?>
    
      <table id="board">

	<tbody>
	  <tr class="board_row">
	  <?php
	    for ($i=0; $i < $taille; $i++) {
	      echo '<td class="board_cell" id="cell-0.'.$i.'"><img src="img/cachee.png" onclick="click_card(this)" row="0" col="'.$i.'" class="board_image" id="img-0.'.$i.'"></td>';
	    }
	  ?>
	  </tr>
	  <tr class="board_row">
	  <?php
	    for ($i=0; $i < $taille; $i++) {
	      echo '<td class="board_cell" id="cell-1.'.$i.'"><img src="img/cachee.png" onclick="click_card(this)" row="1" col="'.$i.'" class="board_image" id="img-1.'.$i.'"></td>';
	    }
	  ?>
	  </tr>
	</tbody>
      </table>

      <div style="visibility: hidden;" id="countdown_full">
	<div id="countdown"></div>
      </div>

      <script type="text/javascript">
	    deal_cards(<?php echo $taille; ?>, <?php echo '"'.$nom.'"'; ?>);
      </script>
    </div>

  </body>
</html>
