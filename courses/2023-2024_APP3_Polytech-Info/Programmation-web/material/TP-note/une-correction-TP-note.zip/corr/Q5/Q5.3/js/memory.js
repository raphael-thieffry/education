// Cette fonction permet de mélanger aléatoirement le contenu d'un tableau
function shuffle(array) {
	let currentIndex = array.length, temporaryValue, randomIndex;
	
	while (0 !== currentIndex) {
		
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;
		
		temporaryValue = array[currentIndex];
		array[currentIndex] = array[randomIndex];
		array[randomIndex] = temporaryValue;
	}
	
	return array;
}


let board; 
function deal_cards(card_number) {
     // Créer un tableau vide nommé card_list
     let card_list = [];
     // Ajouter deux fois chaque carte à ce tableau
     // (une carte pourra être représentée par le chemin d'accès au fichier correspondant ;
     // les fichiers sont numérotés, le chemin est donc "./img/image" + card_index + ".png")
     for (var i = 1 ; i <= card_number ; i++) {
       card_list.push("./img/image"+i+".png");
       card_list.push("./img/image"+i+".png");
     }
     console.log(card_list);
     // Initialisation d'une variable probablement utile pour plus tard :
     // le nombre de cartes cachées restant sur le plateau
     remaining_cards = card_number;
     // On mélange les cartes
     shuffle(card_list);
     // On crée un tableau à deux dimensions pour le plateau
     board = new Array(2);
     // On remplit ce tableau avec les cartes mélangées
     // Parcours des lignes
     for (row_index = 0 ; row_index < 2 ; row_index++) {
         board[row_index] = new Array(card_number);
         // Parcours des colonnes
         for (col_index = 0 ; col_index < card_number ; col_index++) {
             // On ajoute une carte dans la case ligne/colonne :
             // 1. Ajout dans la matrice javascript
	     board[row_index][col_index]=card_list[(row_index*card_number)+col_index];
         }
	 console.log(board[row_index]);
     }
}

var previousCard=null;
function click_card(c) {

  // on ne fait rien, si la carte est déjà trouvée
  if (c.classList.contains("found")) {
    return;
  }
  let ro=c.getAttribute("row");
  let co=c.getAttribute("col");
  console.log(ro, co);
  console.log(board[ro][co]);
  c.setAttribute("src", board[ro][co]);

  if (previousCard==null) { // Première carte tirée
    previousCard = c;
  } else { // Seconde carte tirée
    if (c == previousCard) { // Si on a recliqué sur la même carte
      console.log("Déjà cliquée");
      return;
    }

    if (c.getAttribute("src")==previousCard.getAttribute("src")) {
      console.log("Carte identique");
      c.classList.add("found");
      previousCard.classList.add("found");
      previousCard = null;
    }
    else {
        c.setAttribute("src", "img/cachee.png");
        previousCard.setAttribute("src", "img/cachee.png");
        previousCard = null;
    }
  }
}
