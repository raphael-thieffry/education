<?php
function imc($m,$t){
	return round
		(
			10000 * $m/($t*$t),
			2
		);
}
?>
