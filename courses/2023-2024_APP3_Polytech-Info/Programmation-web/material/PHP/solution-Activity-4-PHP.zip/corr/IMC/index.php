<?php
include './include/data.inc.php';
include './include/imc.php';
?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8">
		<title>IMC</title>
	<link rel="stylesheet" href="/tacit.css">
	<link rel="stylesheet" href="./css/style.css">
	</head>
	<body container>
		<h2>Exercice 3 : IMC </h2>
			<table>
				<thead> 
					<tr>
						<th>Nom</th>
						<th>Prénom</th>
						<th>Email</th>
						<th>Taille</th>
						<th>Poids</th>
						<th>IMC</th>
					</tr>
				</thead>
				<tbody>
						<?php
							foreach ($data as $ligne){
								$taille=$ligne['Taille'];
								$poids=$ligne['Poids'];
								$imc=imc($poids,$taille);
								$class=($imc >=25) ? "_bg-state-warning":"";
								echo "<tr class='$class'>";
								echo "<td>".$ligne['Nom']."</td>";
								echo "<td>".$ligne['Prenom']."</td>";
								echo "<td>".$ligne['Email']."</td>";
								echo "<td>".$ligne['Taille']."</td>";
								echo "<td>".$ligne['Poids']."</td>";
								echo "<td>$imc</td>";
								echo "</tr>";
							}
							?>
				</tbody>
			</table>
	</body>
</html>
