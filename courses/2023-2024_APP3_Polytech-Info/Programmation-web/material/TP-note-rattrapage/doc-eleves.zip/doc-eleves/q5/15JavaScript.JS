//Javascript for Fifteenpuzzle.html by Abdullah Hadid, and a little help from the internet 

var empty;
var Number_of_moves;
var checkWin = false;
var time=0;
var tileID = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16];

window.addEventListener("load", startTimer, false);

function start() {
    Number_of_moves = 0;
    checkWin = false;

    for(var i=0; i < 16; i++) {
        var tmp = document.getElementById(i);
        tmp.className = "cell" ; 
    }

 
    // ceci teste s'il y a une solution
    randomNumber = tileID.sort(function () { return (Math.round(Math.random())-0.5);});
    while(!Problem.prototype.is_solvable(randomNumber)) {
        randomNumber = tileID.sort(function () { return (Math.round(Math.random())-0.5);});
    }

       // cette parti assigne à une cellule la class "cell empty", les autres ont toujours le nom de votre classe. 
    for(var i=0; i < 16; i++) {
        var tmp = document.getElementById(i);
        if(randomNumber[i] == 16) {
            tmp.className = "cell empty";
            tmp.innerHTML = "";
            empty = i; // ceci est l'index du cellule empty
        }
        else
            tmp.innerHTML = randomNumber[i];
    }

}

function doClick(x)
{
    if(checkWin)
        return;

    if(x.id != empty+'') {

        // TODO 1: trouvez si la cellule / casse cliquée est à coté (gauche, droit, nord, sud) de la cellule avec index "empty" 

        // TODO 2: si oui mettez le chiffre de la casse cliqué dans l'ancienne cellule empty (et empty sera dans la possition liberé)

        // TODO 3: mettez à jour les mouvements faites et l'ajouter dans la page HTML
            
            if(isDone()){
                checkWin = true;
                document.getElementById("moves").innerHTML = "CONGRATS! Number of moves it took to complete: " + Number_of_moves;
				if(confirm("Would you like to play again?"))
					   window.location.reload();
            }
    }
}

function simpleGame(){
    if(checkWin)
    {
        window.location.reload();
    }
    time = 0;
    Number_of_moves = 0;
    document.getElementById("moves").innerHTML = "Number of moves so far: " + Number_of_moves;
    for(var i=0; i < 16; i++) {
        var tmp = document.getElementById(i);
        if(i == 14) {
            tmp.className = "cell empty";
            tmp.innerHTML = "";
            empty = i;
        }
        else if(i == 15) {
            tmp.className = "cell";
            tmp.innerHTML = "15";
        }
        else{
            tmp.innerHTML = i+1;
            tmp.className = "cell";
        }
    }
}



Array.prototype.clone = function() { return this.slice(0); };
Array.prototype.swap = function(i1,i2) {
    var copy = this.clone();
    var tmp = copy[i1];
    copy[i1] = copy[i2];
    copy[i2] = tmp;
    return copy;
};


var Problem = function(start_state) {
    this.init_state = start_state;
    return this;
}

Problem.prototype.is_solvable = function(start) {
    start = start.clone();    start.splice(start.indexOf(16), 1);
    start[15] = 16;
    var count = 0;
    for(var i = 0; i < 15; i++) {
        if(start[i] != i+1) {
            count++;
            var j = start.indexOf(i+1);
            start[j] = start[i];
            start[i] = i+1;
        }
    }
    return count % 2 == 0;
}


function isDone() {

    // TODO: tester si les chiffres sont dans le bon cellule, càd que dans cellule 0 nous avons le chiffre 1, dans cellule 1 le chiffre 2, ... et dans cellule 14 le chiffree 15 (cellule 16 doit être empty)
return ... ; // à envoyer True ou False
}


function startTimer()
{
    window.setInterval("updateTime()", 1000);
} 

function updateTime()
{ 
    // TODO 1 : augmenter le temps écoulé par 1
    // TOD0 2 : montrer le temps dans la page HTML
} 
