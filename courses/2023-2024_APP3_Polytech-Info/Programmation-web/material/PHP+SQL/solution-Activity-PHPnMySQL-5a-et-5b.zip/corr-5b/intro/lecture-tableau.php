<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Lecture de la table table1, presentée en tableau html </title>
</head> 
<body> 

<?php 
  /* identifiants pour la connexion avec la BDD */
  /* à adapter selon la configuration           */
  $host="127.0.0.1:3306";
  $user="sql-connect";
  $pass="test";
  $base="appinfo";

  /* connexion à la BDD */
  $bdd = mysqli_connect($host,$user,$pass,$base);

  if (!$bdd)
    die('Echec de connexion au serveur de base de donnees:'.mysqli_connect_error().' '.mysqli_connect_errno());

  echo "connexion réussie à la base de données… <br/><br/>";


  /* fixe le jeu de caractères de la BDD en UTF-8 */
  mysqli_set_charset($bdd, "utf8");
  /* envoi de la requête de lecture */
  $query="SELECT * FROM table1 LIMIT 0,30"; // requete SQL

  if ($reponse=mysqli_query($bdd,$query)) {
    $nb=mysqli_num_rows($reponse); // nb de lignes du résultat
    echo "Nombre de personnes dans la base:".$nb."<br/><br/>";
    if ($nb!=0) {

        echo "<table>
        <tr>
          <th>Nom</th>
          <th>Prenom</th>
        </tr>
        ";

      while($ligne = mysqli_fetch_array($reponse)) {
        $nom = $ligne['nom'];
        $prenom = $ligne['prenom'];
        echo "<tr> <td>".$nom."</td> <td>".$prenom."</td></tr>";
   	   }
    }

    echo "</table>";

    /* libération la mémoire utilisée par les réponses */
    mysqli_free_result($reponse);
  } 
  /* déconnexion de la BDD */
  mysqli_close($bdd);
?> 

</body> 
</html>