-- phpMyAdmin SQL Dump
-- version 4.3.12
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Lun 15 Juin 2015 à 15:29
-- Version du serveur :  5.5.42
-- Version de PHP :  5.4.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `testtbl`
--

CREATE TABLE IF NOT EXISTS `testtbl` (
  `id` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `mdp` varchar(20) NOT NULL,
  `visite` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `testtbl`
--

INSERT INTO `testtbl` (`id`, `login`, `nom`, `prenom`, `mdp`, `visite`) VALUES
(1, 'jdup', 'Dupont', 'Jean', 'test', '2015-06-15 17:15:01'),
(2, 'emartin', 'Martin', 'Eric', 'qsd', '2015-06-15 17:27:48'),
(3, 'aze', 'Zerty', 'A', 'lalala', '2015-06-15 17:27:28');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `testtbl`
--
ALTER TABLE `testtbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `testtbl`
--
ALTER TABLE `testtbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
