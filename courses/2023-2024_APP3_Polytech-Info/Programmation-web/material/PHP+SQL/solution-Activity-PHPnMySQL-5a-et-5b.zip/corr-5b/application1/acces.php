<?php
/* définition du fuseau horaire pour la date */
date_default_timezone_set("Europe/Paris");

/* récupération des données du formulaire accès */
/* utilisation de !empty car $_POST est toujours set donc isset renvoie
  toujours true */
if (!empty($_POST['login']) && !empty($_POST['mdp'])) {
  $login= $_POST['login'];
  $pwd= $_POST['mdp'];
  $vide=0;
} else {
  $vide=1;
}

if (!$vide) {

  /* récupération des identifiants pour connexion avec la BDD */

  include('id_bdd.php');

  /* connexion à la BDD */

  $bdd = mysqli_connect($host,$user,$pass,$base);
  if (!$bdd)
    die('Echec de connexion au serveur de base de donnees:'.mysqli_connect_error().' '.mysqli_connect_errno());
  //echo "Connecté à la base de données";
  //echo "<br />";

  /* Fixe le jeu de caractères de la BDD en UTF-8 */
  mysqli_set_charset($bdd, "utf8");

  /* envoi de la requête de lecture */
  $query="SELECT * FROM testtbl WHERE login='$login'";
  $reponse=mysqli_query($bdd,$query);

  $bad=1;
  if (mysqli_num_rows($reponse) > 0) {
    $ligne = mysqli_fetch_array($reponse);
    $nom=$ligne['nom'];
    $prenom=$ligne['prenom'];
    $dernierpassage=$ligne['visite'];
    $nouvelledate=date("Y-m-d H:i:s"); // format pour MySQL
    $query="UPDATE testtbl SET visite='$nouvelledate' WHERE login='$login'";
    if (!mysqli_query($bdd,$query)) {
      echo "Erreur: ".mysqli_error($bdd);
    }
    $bad=0;
    }

  /* déconnexion de la BDD */
  mysqli_close($bdd);
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Accès</title>
  <head>
  <body>
    <?php
    if (($bad==1) || ($vide==1)) {
      echo "<p>Erreur, recommencez!</p>";
      } else {
      echo "<p>Identifiant et mot de passe corrects</p>";
      echo "<p>Nous sommes le ".$nouvelledate.".</p>";
      echo "<p>Bonjour ".$prenom." ".$nom."</p>";
      echo "<p>Votre dernier passage remonte au ".$dernierpassage."</p>";
      }

    ?>
    <p>Retour à <a href="index.html">l'accueil</a></p>
  </body>
</html>
