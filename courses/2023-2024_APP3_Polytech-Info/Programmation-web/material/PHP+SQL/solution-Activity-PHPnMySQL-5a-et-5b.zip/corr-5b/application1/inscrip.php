<?php
/* définition du fuseau horaire pour la date */
date_default_timezone_set("Europe/Paris");

/* récupération des données du formulaire d'inscription */
/* utilisation de !empty car $_POST est toujours set donc isset renvoie
  toujours true */
if (!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['login']) AND !empty($_POST['mdp'])) {
  $nom= $_POST['nom'];
  $prenom= $_POST['prenom'];
  $login= $_POST['login'];
  $pwd= $_POST['mdp'];
  echo "OK<br />";
} else {
  /* echo "Formulaire incomplet, recommencez...";*/
  /*  header('Location: index.html');
  ne fonctionne pas toujours: solution redirection en JavaScript */
  echo "<script>
    alert(\"Formulaire incomplet, recommencez...\");
    location.replace(\"inscription.html\");
  </script>";
  exit();
}

/* récupération des identifiants pour connexion avec la BDD */

include('id_bdd.php');

/* connexion à la BDD */

$bdd = mysqli_connect($host,$user,$pass,$base);
if (!$bdd)
  die('Echec de connexion au serveur de base de donnees:'.mysqli_connect_error().' '.mysqli_connect_errno());
echo "Connecté à la base de données";
echo "<br />";

/* Fixe le jeu de caractères de la BDD en UTF-8 */
if (!mysqli_set_charset($bdd, "utf8")) {
  printf("Erreur au chargement du jeu de caractères UTF-8: %s\n", mysqli_error($bdd));
} else {
  printf("Jeu de caractères actuel: %s\n", mysqli_character_set_name($bdd));
}

/* envoi de la requête d'écriture */
$dateinscription=date("Y-m-d H:i:s"); // format pour MySQL
$query="INSERT INTO testtbl (login,nom,prenom,mdp,visite) VALUES('$login','$nom','$prenom','$pwd','$dateinscription')";
if (!mysqli_query($bdd,$query))
  printf("\nErreur à l'écriture dans la base de données: %s\n", mysqli_error($bdd));
else
  printf("\nInscription réussie!");
  
/* déconnexion de la BDD */
mysqli_close($bdd);
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Inscription</title>
  <head>
  <body>
    <p>Retour à <a href="index.html">l'accueil</a></p>
  </body>
</html>
