<?php
/* identifiants pour se connecter à la BDD */
$host="127.0.0.1:3306";
$user="sql-connect";
$pass="test";
$base="appinfo";
?>
