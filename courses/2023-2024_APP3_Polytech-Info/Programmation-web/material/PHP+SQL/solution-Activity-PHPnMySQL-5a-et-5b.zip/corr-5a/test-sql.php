<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Ajouter une ligne BD</title>
</head>
<body>
  <h1>Exemple SQL et PHP </h1>

<?php

echo "pret à se connecter à la BD <br>";
/* identifiants pour la connexion avec la BDD */
  /* à adapter selon la configuration           */
  /* $host="127.0.0.1:3306"; /* ceci est le meme que localhost, mais si on utilise "localhost" MySQL n'utilise pas le bon port de communication. */
  /* L'info sur le port à utiliser avec mysqli est dans http://localhost:8080/dashboard/phpinfo.php section mysqli (souvent 3306). Pensez à ouvrir le port 3306 dans votre serveur XAMPP  */ 
$host="127.0.0.1:3306";
 // $host="localhost";
  $user="sql-connect";
  $pass="test";
  $base="appinfo";

/* connexion à la BDD */
$bdd = mysqli_connect($host,$user,$pass,$base);
  if (!$bdd) {
    echo "On a pas arrivé";
    die('Echec de connexion au serveur de base de données:'.mysqli_connect_error().' '.mysqli_connect_errno());  
  }

echo "connecté à la base de données";

/* Fixe le jeu de caractères de la BDD en UTF-8 */
mysqli_set_charset($bdd, "utf8");
$query="INSERT INTO table1 (nom,prenom,sexe,annee) 
            VALUES('HUTT','Jabba','O','1975')";
    
mysqli_query($bdd,$query);

/* deconnexion de la BDD */
mysqli_close($bdd);


?>
</body>
</html>