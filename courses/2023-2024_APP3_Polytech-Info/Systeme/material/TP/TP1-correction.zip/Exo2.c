#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char** argv)
{
  pid_t pid_fils;

  if( argc > 1 )
  {
    if( (pid_fils = fork()) == -1 )
    {
      fprintf(stderr,"Erreur fork...");
      return 0;
    }
    if( pid_fils )
    { // On est dans le pere
      waitpid(pid_fils,NULL,0);
      printf("Fin de l execution...\n");
    }
    else
    { // On est dans le fils
	
      execvp(argv[1],&argv[1]);
      printf("Jamais execute...\n");
    }
  }
  else
    printf("Aucune commande passee en argument...\n");

  return 0;
}
