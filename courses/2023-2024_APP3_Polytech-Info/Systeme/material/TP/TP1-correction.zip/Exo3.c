#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char** argv)
{
  unsigned int   i=1, delai;

  while( 1 )
  {
    printf("N = %d\n",i++);
    for(delai=0;delai<0x0FFFFFFF;delai++);
  }

  return 0;
}
