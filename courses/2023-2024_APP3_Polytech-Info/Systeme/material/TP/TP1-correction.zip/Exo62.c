#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>

void *premier_fils(void *id_pere)
{
  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
  pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,NULL);

  printf("Fils1: Debut\n");
  sleep(10);
  printf("Fils1: je tue mon pere\n");
  pthread_cancel(*((pthread_t*)id_pere));
  while( 1 );
  pthread_exit(0);
}

void *second_fils(void *id_fils_1)
{
  printf("Fils2: Debut\n");
  sleep(20);
  printf("Fils2: j assassine mon frere\n");
  pthread_cancel(*((pthread_t*)id_fils_1));
  sleep(10);
  printf("Fils2: je me suicide...\n");
  pthread_exit(0);
}

void *process_pere(void *arg)
{
  pthread_t my_id = pthread_self(), pthread_id_fils_1, pthread_id_fils_2;
  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
  pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,NULL);

  pthread_create(&pthread_id_fils_1,NULL,premier_fils,&my_id);
  pthread_create(&pthread_id_fils_2,NULL,second_fils,&pthread_id_fils_1);

  while( 1 );
}

int main(void)
{
  pthread_t pthread_id_pere;

  pthread_create(&pthread_id_pere,NULL,process_pere,NULL);
  
  pthread_join(pthread_id_pere,NULL);
  printf("le pere est mort\n");
  sleep(40);
  printf("fin");
  return 0;
}
