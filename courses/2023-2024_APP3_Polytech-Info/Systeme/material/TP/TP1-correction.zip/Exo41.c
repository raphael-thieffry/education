#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char** argv)
{
  pid_t pid_fils;

  if( (pid_fils = fork()) == -1 )
  {
    fprintf(stderr,"Erreur fork...");
    return 0;
  }
  if( !pid_fils )
  { // On est dans le fils
    execlp("who","who",NULL);
  }

  if( (pid_fils = fork()) == -1 )
  {
    fprintf(stderr,"Erreur fork...");
    return 0;
  }
  if( !pid_fils )
  { // On est dans le fils
    execlp("ps","ps",NULL);
  }

  if( (pid_fils = fork()) == -1 )
  {
    fprintf(stderr,"Erreur fork...");
    return 0;
  }
  if( !pid_fils )
  { // On est dans le fils
    execlp("ls","ls","-l","/usr",NULL);
  }

  return 0;
}
