#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define GOOD_VERSION

int main(int argc, char** argv)
{
  int N, i;
  pid_t pid_fils_1 = 0, pid_fils_2 = 0;

  if( argc < 2 )
    printf("Merci de preciser N !!!!\n");
  else
  {
    N = atoi(argv[1]);
    if( (pid_fils_1 = fork()) == -1 )
    {
      fprintf(stderr,"Erreur fork!!!");
      return 0;
    }
    if( !pid_fils_1 )
    { // On est dans le premier fils
      N >>= 1;
      for( i=1 ; i<=N ; i++ )
        printf("%d\n",i);
      exit(0);
    }
    // On est dans le pere
#ifdef GOOD_VERSION
    waitpid(pid_fils_1,NULL,0);
#endif
    if( (pid_fils_2 = fork()) == -1 )
    {
#ifndef GOOD_VERSION
	  // Si nous ne sommes pas dans la bonne version du code, nous n'avons pas attendu le premier fils avant
	  // Nous devons donc l'attendre ici afin de quitter le programme proprement
      waitpid(pid_fils_1,NULL,0);
#endif
      fprintf(stderr,"Erreur fork!!!");
      return 0;
    }
    if( !pid_fils_2 )
    { // On est dans le second fils
      for( i=(N>>1)+1 ; i<=N ; i++ )
        printf("%d\n",i);
      exit(0);
    }
    // On est dans le pere
#ifndef GOOD_VERSION
	// Si nous ne sommes pas dans la bonne version du code, nous attendons les deux fils à la fin du programme
	// ils s'exécutent alors en parallèle et leurs affichages se retrouvent emmêlés
    waitpid(pid_fils_1,NULL,0);
#endif
    waitpid(pid_fils_2,NULL,0);
  }

  return 0;
}
