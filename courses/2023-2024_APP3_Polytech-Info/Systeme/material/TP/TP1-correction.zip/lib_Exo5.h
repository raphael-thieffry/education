#ifndef _LIB_EXO5_H_
#define _LIB_EXO5_H_

void lib_exo5_hello_world(void);

#endif
