#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
  pid_t pid_fils_1, pid_fils_2, pid_pere = getpid();

  printf("Pere: mon pid est %d\n",getpid());

  if( !(pid_fils_1 = fork()) )
  {  // On est dans le premier fils
    printf("Fils1: mon pid est %d\n",getpid());
    sleep(10);
    kill(pid_pere,SIGKILL);
    printf("Fils1: Je viens de tuer mon pere\n");
    while( 1 );
  }
  printf("Pere: Je viens d'avoir un fils\n");

  if( !(pid_fils_2 = fork()) )
  { // On est dans le second fils
    printf("Fils2: mon pid est %d\n",getpid());
    sleep(20);
    printf("Fils2: Je viens d assassiner mon frere\n");
    kill(pid_fils_1,SIGKILL);
    sleep(10);
    printf("Fils2: Je me suicide...\n");
    exit(0);
  }
  printf("Pere: Je viens d'avoir un second fils\n");

  while( 1 );

  return 0;
}
