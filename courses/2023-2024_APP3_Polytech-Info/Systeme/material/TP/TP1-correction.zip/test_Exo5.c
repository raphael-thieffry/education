#include "lib_Exo5.h"

int main(void)
{
  lib_exo5_hello_world();
  return 0;
}
