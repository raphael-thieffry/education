#include "lib_Exo5.h"
#include <stdio.h>

void lib_exo5_hello_world(void)
{
  printf("Hello world...\n");
}
