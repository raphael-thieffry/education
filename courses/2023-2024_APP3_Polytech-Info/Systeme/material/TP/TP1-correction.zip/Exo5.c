#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char** argv)
{
  char  Compilation_OK;
  char** argu;
  int   i, status;
  pid_t *pid_fils;

  if( argc < 2 )
  {
    printf("Aucun fichier en argument !!!\n");
    return 0;
  }
  
  // Il y a argc-1 fichiers à compiler
  pid_fils = (pid_t*)malloc(sizeof(pid_t)*(argc-1));
  // Création d un fils pour compiler chaque fichier
  for(i=0;i<(argc-1);i++)
  {
    if( !(pid_fils[i] = fork()) )
    { // On est dans le ième fils
      execlp("gcc","gcc","-c",argv[i+1],NULL);
      exit(55);
    }
  }
  // Le pere attend que tous ses fils soient termines et verifie si
  // leur compilation s est bien deroulee
  Compilation_OK = 1;
  for(i=0;i<(argc-1);i++)
  {
    waitpid(pid_fils[i],&status,0);
    if( WEXITSTATUS(status) ) Compilation_OK = 0;
  }
  // Le pere peut maintenant libérer l'espace alloué pour stocker les pid de ses fils
  free(pid_fils);

  if( !Compilation_OK )
  {
    printf("Erreur de compilation !!!\n");
    return 0;
  }


  // On prépare les arguments pour l'edition des liens avec gcc
  argu = (char**)malloc(sizeof(char*)*(argc+3));
  argu[0] = "gcc";
  for(i=1;i<argc;i++)
  {
    argu[i] = argv[i];
    argu[i][strlen(argv[i])-1] = 'o';
  }
  argu[argc] = "-o";
  argu[argc+1] = "sortie";
  argu[argc+2] = NULL;
  execvp(argu[0],argu);

  return 0;
}
